self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9ccc4d3ee2f3116957a7c8c4373a67db",
    "url": "/index.html"
  },
  {
    "revision": "d8d426c6bdfdacb56897",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "879997ca7b0195945da8",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "d8d426c6bdfdacb56897",
    "url": "/static/js/2.4c298483.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.4c298483.chunk.js.LICENSE.txt"
  },
  {
    "revision": "879997ca7b0195945da8",
    "url": "/static/js/main.082dda91.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);