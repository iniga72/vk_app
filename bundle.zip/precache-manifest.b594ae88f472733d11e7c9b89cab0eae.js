self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "752eddb75d52b6022d74b4e8aff0df9c",
    "url": "/index.html"
  },
  {
    "revision": "ccf8f9a51a3e8c9f16e5",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "d90468f53017fa425a4c",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "ccf8f9a51a3e8c9f16e5",
    "url": "/static/js/2.e7233e72.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.e7233e72.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d90468f53017fa425a4c",
    "url": "/static/js/main.52882533.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);