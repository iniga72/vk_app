self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9420d36074e7ca4155e7fd17acd86f4e",
    "url": "/index.html"
  },
  {
    "revision": "89c7d1d8f2a1804fb377",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "2d68c2a0054b484e100c",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "89c7d1d8f2a1804fb377",
    "url": "/static/js/2.9eb6d5b7.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.9eb6d5b7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2d68c2a0054b484e100c",
    "url": "/static/js/main.b59992ed.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);