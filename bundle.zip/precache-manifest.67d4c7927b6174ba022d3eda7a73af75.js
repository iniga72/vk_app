self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dea373a36920ceac4167389b81dfe9b3",
    "url": "/index.html"
  },
  {
    "revision": "aed55ef202da345e865b",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "20268df438bcdea61ef3",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "aed55ef202da345e865b",
    "url": "/static/js/2.6634687a.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.6634687a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "20268df438bcdea61ef3",
    "url": "/static/js/main.c2791c71.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);