self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "197d7eff286b78be057ef8f51cf0fc27",
    "url": "/index.html"
  },
  {
    "revision": "fe8517ac512dc0d8ebc9",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "0487cbb26e72d6368c34",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "fe8517ac512dc0d8ebc9",
    "url": "/static/js/2.635b2a36.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.635b2a36.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0487cbb26e72d6368c34",
    "url": "/static/js/main.f027b54e.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);