self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bc9a557ef667c5cc22be03cc4ed05c2f",
    "url": "/index.html"
  },
  {
    "revision": "89c7d1d8f2a1804fb377",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "7cf548424d03e9f8167f",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "89c7d1d8f2a1804fb377",
    "url": "/static/js/2.9eb6d5b7.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.9eb6d5b7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7cf548424d03e9f8167f",
    "url": "/static/js/main.1b852dcc.chunk.js"
  },
  {
    "revision": "4a42fdcbdfd3cf55fea3",
    "url": "/static/js/runtime-main.1c47a842.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);